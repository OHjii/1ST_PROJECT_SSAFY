# 거기어디니? backend python

## 공통프로젝트 2주차(200120 ~ 200123)

### 이번 주에 할 일

- django 기본 세팅 진행

- django에 mysql 연결

- django instagram crawling 테스트
