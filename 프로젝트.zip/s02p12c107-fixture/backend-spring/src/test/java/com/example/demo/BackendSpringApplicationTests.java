package com.example.demo;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
