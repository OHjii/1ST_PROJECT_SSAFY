<template>
  <div id="my-favorite">
      <v-card app background-color="#0000">
        <v-container fluid>
          <v-row dense>
            <v-col v-for="(item, i) in list" :key="i" cols="4">
              <v-card>
                <v-img
                  :src = item.psource
                  class="white--text align-end"
                  gradient="to bottom, rgba(0,0,0,.1), rgba(0,0,0,.5)"
                  height="200px"
                >
                </v-img>
                <!-- <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn icon>
                    ❤️
                    <v-icon @click="delfavorite()">mdi-heart</v-icon>
                  </v-btn>
                </v-card-actions> -->
              </v-card>
            </v-col>
          </v-row>
        </v-container>
      </v-card>

  </div>
</template>

<script>
import axios from "axios";

export default {
  data: () => ({
    list:[],
  }),

  methods:{
     showfavorite() {
      const basicUrl = "http://127.0.0.1:8090/";
      const addUrl = "api/favorite/selectMyList/";
      // const cid = this.cid;
      const fid = "123@123"; // 현재 아이디 박아놓은 상태.
      axios
        .get(basicUrl+addUrl+fid)
        .then(response => (this.list = response.data['resvalue']))
        .catch(() => {
               this.errored = true;
         })
        . finally(() => (this.loading = false));
    },
    delfavorite(){
      this.is_show = !this.is_show; // #2, #3
    }
  
  },
  mounted(){
    this.showfavorite();
  }

};
</script>
