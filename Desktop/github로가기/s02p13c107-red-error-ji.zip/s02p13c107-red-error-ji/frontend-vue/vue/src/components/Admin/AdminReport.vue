<template>
  <v-col cols="12" md="6" sm="12">
    <v-alert
      border="top"
      colored-border
      color="red"
      elevation="2"
      class="text-center font-weight-bold"
    >User report board</v-alert>
  </v-col>
</template>

<script>
export default {};
</script>

<style>
</style>
