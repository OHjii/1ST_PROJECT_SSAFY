<template>
  <v-progress-circular indeterminate color="blue"></v-progress-circular>
</template>

<script>
export default {};
</script>

<style scoped>
.v-progress-circular {
  margin: 1rem;
}
</style>
