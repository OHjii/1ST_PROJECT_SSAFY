export default {
  PUSH_MSG_DATA: "pushMsgData"
};
