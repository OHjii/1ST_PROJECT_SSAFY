import csv

def save_to_file(mango):
  file = open("res.xml", mode="w")
  writer = csv.writer(file)
  writer.writerow(["title"])
  for i in mango:
    # writer.writerow(list(i.values()))
    writer.writerow(i)

  return