from ex1 import *
from flask import Flask, render_template

app = Flask(__name__)


names = get_names()
img_names = get_img_names()


@app.route('/')

def result():
    dict = [names,img_names]
    # dict={'name':names,'img_name':img_names}
    return render_template('main.html', res = dict)

if __name__ == '__main__':
    app.run(debug=True)

# import requests
# from bs4 import BeautifulSoup
 
# response = requests.get('https://www.mangoplate.com/')
 
# print(response)
# print(response.text)