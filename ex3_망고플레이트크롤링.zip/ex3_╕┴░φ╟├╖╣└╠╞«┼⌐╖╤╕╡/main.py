﻿from save import save_to_file
from ex1 import get_names
from main_html import hello_name

names = get_names()
# print(names)
save_to_file(names)
# hello_name = hello_name()


