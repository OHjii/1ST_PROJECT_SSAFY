import requests
from bs4 import BeautifulSoup as bs
import urllib.parse

# baseUrl = 'https://www.mangoplate.com/search/'
# plusUrl = input('지역을 입력하세요 : ')

# 일단 광주 검색으로 박아버렸음
baseUrl = 'https://www.mangoplate.com/search/%EA%B4%91%EC%A3%BC'
plusUrl = ''

# 한글 검색 자동 변환
url = baseUrl + urllib.parse.quote_plus(plusUrl)
print(url)

# 그냥 하면 막혀서 헤더를 설정해줌
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
    'Referer': 'https://www.mangoplate.com/',
}
html = requests.get(url, headers=headers).text

bsObject = bs(html, "html.parser")

# 조건에 맞는 파일을 다 출력해라
# title = bsObject.find_all(class_='info')
# title = bsObject.find_all("h2")
titles = bsObject.find_all('h2',class_='title')
imgs = bsObject.findAll('img',class_='center-croping lazy')
# title_s = bsObject.find('h2', class_='title')
# print(title_s.get_text())
# # print(title.get_text())
# # paragraph_data = soup.find('p', class='cssstyle')
def extract_img_names():
    img_names = []
    for img in imgs:
        img_names.append(img['data-original'])
    return img_names

def get_img_names():
    img_names = extract_img_names()
    # print(names)
    return img_names
       

def extract_names():
    names = []
    for title in titles:
    #   print(i)
        i = title.get_text()
        # print(i)
        names.append(i)
    return names

def get_names():
    names = extract_names()
    # print(names)
    return names
       
